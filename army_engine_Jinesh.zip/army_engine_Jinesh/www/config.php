<?php
ob_start();

$host = 'jinesh-mysql-app';
$dbname = 'jinesh_db';
$username = 'root';
$password = 'root';

try {
    $con = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
	//echo "connection success";
	$x = $con->prepare("SHOW TABLES LIKE 'sites';");
	$x->execute();
	$row = $x->fetch();
	if ($row) {
	}
	else{
		$query = $con->prepare("CREATE TABLE `sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(512) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(512) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(512) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `keywords` varchar(512) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `clicks` int(11) NOT NULL,
  PRIMARY KEY(`id`)
)");
	$query->execute();
	}
    //echo "Connected to $dbname at $host successfully.";
} catch (PDOException $pe) {
    die("Could not connect to the database $dbname :" . $pe->getMessage());
}