<!doctype html>
<html lang="en-us">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Indian Army Submit Url</title>
	<link rel="icon" href="assets/images/army1.png" type="image/icon type">
    <link rel="stylesheet" href="assets/css/style.css">
    <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
</head>
<body>
<div class="wrapper indexPage">
    <div class="mainSection">
        <div class="logoContainer">
            <img src="assets/images/army1.png" alt="Search Console Submit Url">
			<p style="color:black">Indian Army Engine By Jinesh</p>
        </div>
        <div class="searchContainer">
            <form method="post" id="formSubmitUrl">
                <input type="url" class="searchBox" name="url" placeholder="Enter URL" required>
                <label class="textGradient1"></label>
                <input type="submit" style="color:white;background-color:black" class="searchButton" id="buttonSubmit"  value="Submit"><br>
				<button style="color:white;background-color:black" onclick="location.href='/index.php'">
				Back to Main Page
				</button>
            </form>
        </div>
    </div>
</div>
<script>
    $(document).ready(function() {
        $("#formSubmitUrl").submit(function (e) {
            e.preventDefault();
            $( ".textGradient1" ).text( "Please wait" );
            $("#buttonSubmit").prop('disabled', true);
            $.ajax({
                type: 'post',
                url: 'crawl.php',
                data: $('form').serialize(),
                success: function () {
                    $("#buttonSubmit").text('disabled', false);
                    $( ".textGradient1" ).html( "Data Stored & Crawling Completed" );
                }
            });
        })
    })
</script>
</body>
</html>