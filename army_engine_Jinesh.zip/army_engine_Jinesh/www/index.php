<!doctype html>
<html lang="en-us">
<head>
<style>

.center {
  margin: 0;
  position: absolute;
  left: 50%;
  -ms-transform: translate(-50%, -50%);
  transform: translate(-50%, -50%);
}
</style>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Indian Army Engine by Jinesh Patel</title>
	<link rel="icon" href="/assets/images/army1.png" type="image/icon type">
    <link rel="stylesheet" href="assets/css/style.css">
	
</head>
<body>
    <div class="wrapper indexPage">
        <div class="mainSection">
            <div class="logoContainer">
                <img src="assets/images/army1.png" alt="Indian Army Title">
				<p>Indian Army Engine By Jinesh</p>
            </div>
            <div class="searchContainer">
                <form action="search.php" method="get">
                    <input type="text" class="searchBox" name="term" required>
                    <input type="submit" style="color:white;background-color:black" class="searchButton" value="Search"> 
                    <?php
			include("config.php");
		    ?>
                </form>
		<br>
		
  			<div class="center">
				<button  style="color:white;background-color:black" onclick="location.href='/crawl_url.php'">
				Crawl
				</button>
			</div>
		
				
				
            </div>
        </div>
    </div>
</body>
</html>